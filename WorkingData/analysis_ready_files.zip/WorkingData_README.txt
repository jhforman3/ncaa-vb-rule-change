Working Data ZIP
================

This archive contains three CSVs:
  - analysis_ready_matches.csv
  - analysis_ready_teams.csv
  - analysis_ready_players.csv

To regenerate these from the raw data, run:
  Rscript code/DataPrep.R

See the top‐level README.md for full instructions.
